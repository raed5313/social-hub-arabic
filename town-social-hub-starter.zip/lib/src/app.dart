import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth_page.dart';
import 'home_page.dart';

const townBlue = Color(0xFF1769E0);

class TownApp extends StatelessWidget {
  const TownApp({super.key, required this.supabaseConfigured});
  final bool supabaseConfigured;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'تاون | TOWN',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: townBlue, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7F9FC),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: Color(0xFF17243A), centerTitle: false),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFDCE5F2))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFDCE5F2))),
        ),
      ),
      home: !supabaseConfigured
          ? const SetupPage()
          : StreamBuilder<AuthState>(
              stream: Supabase.instance.client.auth.onAuthStateChange,
              builder: (context, snapshot) {
                final session = Supabase.instance.client.auth.currentSession;
                return session == null ? const AuthPage() : const HomePage();
              },
            ),
    );
  }
}

class SetupPage extends StatelessWidget {
  const SetupPage({super.key});
  @override
  Widget build(BuildContext context) => const Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(body: Center(child: Padding(
      padding: EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.forum_rounded, size: 68, color: townBlue),
        SizedBox(height: 14),
        Text('تاون | TOWN', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: townBlue)),
        SizedBox(height: 10),
        Text('اربط التطبيق بمشروع Supabase أولاً', textAlign: TextAlign.center, style: TextStyle(fontSize: 17)),
        SizedBox(height: 8),
        Text('راجع README.md لإضافة رابط المشروع والمفتاح العام عبر dart-define.', textAlign: TextAlign.center),
      ]),
    ))),
  );
}
