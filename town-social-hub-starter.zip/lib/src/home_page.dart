import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'app.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int _tab = 0;
  final _post = TextEditingController();
  bool _sending = false;

  Future<List<Map<String, dynamic>>> _loadPosts() async {
    final rows = await Supabase.instance.client.from('posts').select('id, content, created_at, user_id').order('created_at', ascending: false).limit(50);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> _createPost() async {
    final content = _post.text.trim();
    if (content.isEmpty) return;
    setState(() => _sending = true);
    try {
      await Supabase.instance.client.from('posts').insert({'content': content, 'user_id': Supabase.instance.client.auth.currentUser!.id});
      _post.clear();
      if (mounted) { setState(() => _tab = 0); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نشر منشورك'))); }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لم يتم النشر. تأكد من تشغيل مخطط قاعدة البيانات.')));
    } finally { if (mounted) setState(() => _sending = false); }
  }

  @override
  void dispose() { _post.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _feed(),
      const _Placeholder(icon: Icons.search, title: 'اكتشف', subtitle: 'البحث عن الأشخاص والمنشورات قيد التطوير'),
      _compose(),
      const _Placeholder(icon: Icons.chat_bubble_outline, title: 'الرسائل', subtitle: 'ستُضاف المحادثات الخاصة في المرحلة التالية'),
      _profile(),
    ];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: const Row(children: [Icon(Icons.forum_rounded, color: townBlue), SizedBox(width: 8), Text('تاون', style: TextStyle(fontWeight: FontWeight.w800, color: townBlue))]), actions: [IconButton(tooltip: 'تسجيل الخروج', onPressed: () => Supabase.instance.client.auth.signOut(), icon: const Icon(Icons.logout))]),
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.search), label: 'اكتشف'),
          NavigationDestination(icon: Icon(Icons.add_box_outlined), label: 'نشر'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'الرسائل'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    ));
  }

  Widget _feed() => RefreshIndicator(
    onRefresh: () async => setState(() {}),
    child: FutureBuilder<List<Map<String, dynamic>>>(
      future: _loadPosts(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return ListView(children: const [SizedBox(height: 120), _Placeholder(icon: Icons.cloud_off, title: 'تعذر تحميل المنشورات', subtitle: 'شغّل ملف supabase/schema.sql وتحقق من الاتصال')]);
        final posts = snap.data ?? [];
        if (posts.isEmpty) return ListView(children: const [SizedBox(height: 90), _Placeholder(icon: Icons.dynamic_feed, title: 'مرحباً بك في تاون', subtitle: 'لا توجد منشورات بعد. كن أول من يشارك شيئاً!')]);
        return ListView.builder(padding: const EdgeInsets.all(12), itemCount: posts.length, itemBuilder: (context, i) {
          final p = posts[i];
          return Card(color: Colors.white, margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const CircleAvatar(backgroundColor: Color(0xFFE5EEFF), child: Icon(Icons.person, color: townBlue)), const SizedBox(width: 10), Expanded(child: Text('عضو تاون', style: const TextStyle(fontWeight: FontWeight.bold))), const Icon(Icons.more_horiz)]),
            const SizedBox(height: 14),
            Text('${p['content'] ?? ''}', style: const TextStyle(fontSize: 16)),
            const Divider(height: 24),
            const Row(children: [Icon(Icons.thumb_up_alt_outlined, size: 20, color: townBlue), SizedBox(width: 6), Text('إعجاب'), SizedBox(width: 24), Icon(Icons.mode_comment_outlined, size: 20), SizedBox(width: 6), Text('تعليق')]),
          ])));
        });
      },
    ),
  );

  Widget _compose() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('منشور جديد', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 14),
    TextField(controller: _post, minLines: 5, maxLines: 10, maxLength: 2000, decoration: const InputDecoration(hintText: 'بماذا تفكر؟', alignLabelWithHint: true)),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: _sending ? null : _createPost, icon: const Icon(Icons.send), label: Text(_sending ? 'جارٍ النشر...' : 'نشر المنشور')),
  ]);

  Widget _profile() {
    final user = Supabase.instance.client.auth.currentUser;
    final name = user?.userMetadata?['display_name']?.toString();
    return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const CircleAvatar(radius: 42, backgroundColor: Color(0xFFE5EEFF), child: Icon(Icons.person, size: 48, color: townBlue)),
      const SizedBox(height: 12),
      Text((name == null || name.isEmpty) ? 'عضو تاون' : name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      Text(user?.email ?? '', style: const TextStyle(color: Colors.blueGrey)),
      const SizedBox(height: 20),
      const Text('الملف الشخصي الأساسي — ستتم إضافة الصورة والنبذة والمتابعين لاحقاً', textAlign: TextAlign.center),
    ])));
  }
}

class _Placeholder extends StatelessWidget {
  const _Placeholder({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, size: 54, color: townBlue),
    const SizedBox(height: 12),
    Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 6),
    Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.blueGrey)),
  ])));
}
