# تاون | TOWN — Flutter + Supabase

بداية تنفيذية لتطبيق تواصل اجتماعي عربي (Android أولاً) بواجهة RTL وألوان أبيض/أزرق.

## الموجود
- واجهة تسجيل الدخول وإنشاء الحساب عبر Supabase Auth.
- واجهة رئيسية عربية مع تبويبات: الرئيسية، البحث، إنشاء منشور، الرسائل، حسابي.
- نموذج إنشاء منشور نصي وتغذية منشورات من قاعدة البيانات.
- SQL لإنشاء الجداول وسياسات Row Level Security.
- إعدادات Supabase عبر `--dart-define`؛ لا تضع `service_role` داخل التطبيق.

## المتطلبات
- Flutter SDK حديث.
- مشروع Supabase.
- Android Studio أو VS Code.

## التشغيل
1. أنشئ مشروعاً في Supabase.
2. افتح SQL Editor وشغّل الملف `supabase/schema.sql`.
3. من إعدادات Supabase انسخ Project URL و anon/publishable key.
4. شغّل:
   ```bash
   flutter pub get
   flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY
   ```
5. فعّل Email provider في Supabase Authentication.

## ملاحظات مهمة
- هذا إصدار تأسيسي قابل للتطوير وليس تطبيقاً منشوراً أو نظاماً مكتملاً بعد.
- رفع الصور، الرسائل الفورية، الإشعارات، الحظر والإبلاغ، والتحقق المتقدم تحتاج مراحل تنفيذ إضافية.
- لا تستخدم مفتاح `service_role` داخل تطبيق Android.
