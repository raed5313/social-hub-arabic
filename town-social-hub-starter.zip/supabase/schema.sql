-- TOWN / تاون: initial Supabase schema
-- Run this in Supabase SQL Editor. RLS is enabled on all user-facing tables.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'عضو تاون',
  avatar_url text,
  bio text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 2000),
  image_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 1000),
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.follows (
  follower_id uuid not null references auth.users(id) on delete cascade,
  following_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);

create index if not exists posts_created_at_idx on public.posts (created_at desc);
create index if not exists posts_user_id_idx on public.posts (user_id);
create index if not exists comments_post_id_idx on public.comments (post_id, created_at);
create index if not exists follows_following_id_idx on public.follows (following_id);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.likes enable row level security;
alter table public.follows enable row level security;

-- Profiles: authenticated users can read profiles; users can only edit their own.
create policy "Profiles are readable by authenticated users"
on public.profiles for select to authenticated using (true);
create policy "Users insert own profile"
on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Users update own profile"
on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Posts: signed-in users can read; author controls create/update/delete.
create policy "Authenticated users read posts"
on public.posts for select to authenticated using (true);
create policy "Users create own posts"
on public.posts for insert to authenticated with check (auth.uid() = user_id);
create policy "Authors update own posts"
on public.posts for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Authors delete own posts"
on public.posts for delete to authenticated using (auth.uid() = user_id);

-- Comments: authenticated users can read; only author creates/deletes own comments.
create policy "Authenticated users read comments"
on public.comments for select to authenticated using (true);
create policy "Users create own comments"
on public.comments for insert to authenticated with check (auth.uid() = user_id);
create policy "Authors delete own comments"
on public.comments for delete to authenticated using (auth.uid() = user_id);

-- Likes: users can read, add and remove their own likes.
create policy "Authenticated users read likes"
on public.likes for select to authenticated using (true);
create policy "Users add own likes"
on public.likes for insert to authenticated with check (auth.uid() = user_id);
create policy "Users remove own likes"
on public.likes for delete to authenticated using (auth.uid() = user_id);

-- Follows: users can read relationships and manage only their own follows.
create policy "Authenticated users read follows"
on public.follows for select to authenticated using (true);
create policy "Users follow as themselves"
on public.follows for insert to authenticated with check (auth.uid() = follower_id);
create policy "Users unfollow as themselves"
on public.follows for delete to authenticated using (auth.uid() = follower_id);

-- Create a profile automatically when a new auth user is registered.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', 'عضو تاون'))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

grant usage on schema public to authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert, update, delete on public.posts to authenticated;
grant select, insert, delete on public.comments to authenticated;
grant select, insert, delete on public.likes to authenticated;
grant select, insert, delete on public.follows to authenticated;
